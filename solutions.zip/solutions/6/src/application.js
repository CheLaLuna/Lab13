import keyBy from 'lodash/keyBy.js';
import has from 'lodash/has.js';
import isEmpty from 'lodash/isEmpty.js';
import * as yup from 'yup';
import onChange from 'on-change';
import axios from 'axios';

const routes = {
  usersPath: () => '/users',
};

const schema = yup.object().shape({
  name: yup.string().trim().required(),
  email: yup.string().required('email must be a valid email').email(),
  password: yup.string().required().min(6),
  passwordConfirmation: yup.string()
    .required('password confirmation is a required field')
    .oneOf(
      [yup.ref('password'), null],
      'password confirmation does not match to password',
    ),
});

// Этот объект можно использовать для того, чтобы обрабатывать ошибки сети.
// Это необязательное задание, но крайне рекомендуем попрактиковаться.
const errorMessages = {
  network: {
    error: 'Network Problems. Try again.',
  },
};

// Используйте эту функцию для выполнения валидации.
// Выведите в консоль её результат, чтобы увидеть, как получить сообщения об ошибках.
const validate = (fields) => {
  try {
    schema.validateSync(fields, { abortEarly: false });
    return {};
  } catch (e) {
    return keyBy(e.inner, 'path');
  }
};

// BEGIN
export default function app(){
  const validationSchema = yup.object().shape({
    name: yup.string().required(),
    email: yup.string().email().required(),
    password: yup.string().min(6).required(),
    passwordConfirmation: yup.string().oneOf([yup.ref('password'), null], 'Пароли должны совпадать').required(),
  });

  function enableSubmitButton(form, isValid) {
    const submitButton = form.querySelector('input[type="submit"]');
    submitButton.disabled = !isValid;
  }

  function displayFormErrors(form, errors) {
    Object.keys(errors).forEach(fieldName => {
      const input = form.querySelector([name="${fieldName}"]);
      const feedback = input.nextElementSibling;
      if (errors[fieldName]) {
        input.classList.add('is-invalid');
        feedback.textContent = errors[fieldName];
      } else {
        input.classList.remove('is-invalid');
        feedback.textContent = '';
      }
    });
  }

  function setupSignUpForm() {
    const form = document.querySelector('[data-form="sign-up"]');
    const formState = onChange({
      name: '',
      email: '',
      password: '',
      passwordConfirmation: '',
      errors: {},
    }, (path, value) => {
      displayFormErrors(form, formState.errors);
      enableSubmitButton(form, Object.keys(formState.errors).length === 0);
    });

    form.addEventListener('input', event => {
      const { name, value } = event.target;
      formState[name] = value;
      validationSchema.validate(formState, { abortEarly: false })
        .then(() => {
          formState.errors = {};
        })
        .catch(error => {
          const errors = error.inner.reduce((acc, currentError) => {
            acc[currentError.path] = currentError.message;
            return acc;
          }, {});
          formState.errors = errors;
        });
    });

    form.addEventListener('submit', event => {
      event.preventDefault();
      const formData = new FormData(form);
      axios.post('/users', formData)
        .then(response => {
          form.innerHTML = '<div data-container="sign-up">User Created!</div>';
        })
        .catch(error => {
          console.error('Ошибка создания пользователя:', error);
        });
    });
  }
};
// END
