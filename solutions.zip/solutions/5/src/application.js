import uniqueId from 'lodash/uniqueId.js';

// BEGIN
export function app() {
    const lists = {
        General: []
    };
    let currentList = 'General';

    const listsContainer = document.querySelector('[data-container="lists"] ul');
    const tasksContainer = document.querySelector('[data-container="tasks"] ul');
    const newListForm = document.querySelector('[data-container="new-list-form"]');
    const newTaskForm = document.querySelector('[data-container="new-task-form"]');

    if (!listsContainer || !tasksContainer || !newListForm || !newTaskForm) {
        console.error('Один или несколько элементов DOM не найдены');
        return;
    }

    const renderTasks = () => {
        tasksContainer.innerHTML = '';
        lists[currentList].forEach(task => {
            const taskElement = document.createElement('li');
            taskElement.textContent = task;
            tasksContainer.appendChild(taskElement);
        });
    };

    const renderLists = () => {
        listsContainer.innerHTML = '';
        Object.keys(lists).forEach(list => {
            const listElement = document.createElement('li');
            if (list === currentList) {
                listElement.innerHTML = `<b>${list}</b>`;
            } else {
                listElement.innerHTML = `<a href="#">${list}</a>`;
                listElement.addEventListener('click', (event) => {
                    event.preventDefault();
                    currentList = list;
                    renderLists();
                    renderTasks();
                });
            }
            listsContainer.appendChild(listElement);
        });
    };

    newListForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const formData = new FormData(event.target);
        const newListName = formData.get('name').trim();

        if (newListName && !lists[newListName]) {
            lists[newListName] = [];
            currentList = newListName;
            renderLists();
            renderTasks();
            event.target.reset();
        }
    });

    newTaskForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const formData = new FormData(event.target);
        const newTaskName = formData.get('name').trim();

        if (newTaskName) {
            lists[currentList].push(newTaskName);
            renderTasks();
            event.target.reset();
        }
    });

    renderLists();
    renderTasks();
};
export default app;
// END