// BEGIN
export default function app(laptops) {
  const resultDiv = document.querySelector('.result');
  const form = document.querySelector('form');
  const processorSelect = document.querySelector('select[name="processor"]');
  const frequencySelect = document.querySelector('select[name="frequency"]');
  const memorySelect = document.querySelector('select[name="memory"]');

  function renderLaptops(filteredLaptops) {
      resultDiv.innerHTML = '';

      if (filteredLaptops.length === 0) {
          resultDiv.textContent = 'No laptops found';
          return;
      }

      const ul = document.createElement('ul');
      filteredLaptops.forEach((laptop) => {
          const li = document.createElement('li');
          const laptopDetails = `${laptop.model}`;
          li.textContent = laptopDetails;
          ul.appendChild(li);
      });
      resultDiv.appendChild(ul);
  }

  function filterLaptops() {
      const processorFilter = processorSelect.value;
      const frequencyFilter = parseFloat(frequencySelect.value);
      const memoryFilter = parseInt(memorySelect.value);

      const filteredLaptops = laptops.filter((laptop) => {
          return (
              (processorFilter === 'any' || laptop.processor.toLowerCase().includes(processorFilter.toLowerCase())) &&
              (isNaN(frequencyFilter) || laptop.frequency >= frequencyFilter) &&
              (isNaN(memoryFilter) || laptop.memory >= memoryFilter)
          );
      });

      renderLaptops(filteredLaptops);
  }

  form.addEventListener('change', filterLaptops);

  renderLaptops(laptops);
}
// END