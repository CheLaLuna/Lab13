import axios from 'axios';

const routes = {
  tasksPath: () => '/api/tasks',
};

// BEGIN
export async function initializeTodoApp() {
    const form = document.querySelector('.form-inline');
    const input = form.querySelector('input[name="name"]');
    const tasksList = document.getElementById('tasks');

    const createTaskElement = (taskName) => {
        const li = document.createElement('li');
        li.classList.add('list-group-item');
        li.textContent = taskName;
        return li;
    };

    const loadTasks = async () => {
        try {
            const response = await axios.get(routes.tasksPath());
            const tasks = response.data.items;

            tasksList.innerHTML = '';

            tasks.forEach(task => {
                const taskElement = createTaskElement(task.name);
                tasksList.appendChild(taskElement);
            });
        } catch (error) {
            console.error('Error loading tasks:', error);
        }
    };

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const taskName = input.value.trim();
        if (taskName === '') {
            return;
        }

        try {
            const response = await axios.post(routes.tasksPath(), { name: taskName });
            if (response.status === 201) {
                
                const newTaskElement = createTaskElement(taskName);
                tasksList.prepend(newTaskElement);

                input.value = '';
            }
        } catch (error) {
            console.error('Error adding new task:', error);
        }
    });

    await loadTasks();
};
export default initializeTodoApp;
// END