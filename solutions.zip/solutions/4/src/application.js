// BEGIN
export function app(companies) {
    const container = document.querySelector('.container');
    
    companies.forEach((company) => {
        const button = document.createElement('button');
        button.className = 'btn btn-primary';
        button.textContent = company.name;

        button.addEventListener('click', () => {
            const existingDescription = container.querySelector('div.company-description');
            
            if (existingDescription) {
                existingDescription.remove();
                if (existingDescription.dataset.id == company.id) {
                    return;
                }
            }
            
            const descriptionDiv = document.createElement('div');
            descriptionDiv.className = 'company-description';
            descriptionDiv.textContent = company.description;
            descriptionDiv.dataset.id = company.id;
            
            container.appendChild(descriptionDiv);
        });

        container.appendChild(button);
    });
};
export default app;
// END