// BEGIN
export default function calculator(){
  const form = document.querySelector('.form-inline');
  const input = form.querySelector('input[name="number"]');
  const resultDiv = document.getElementById('result');
  const resetButton = form.querySelector('button[type="button"]');

  let sum = 0;

  const handleFormSubmit = (event) => {
      event.preventDefault();

      const value = parseInt(input.value, 10);
      if (!isNaN(value)) {
          sum += value;
          resultDiv.textContent = sum;
      }

      input.value = '';
      input.focus();
  };

  const handleResetButtonClick = () => {
      sum = 0;
      resultDiv.textContent = sum;
      input.value = '';
      input.focus();
  };

  form.addEventListener('submit', handleFormSubmit);
  resetButton.addEventListener('click', handleResetButtonClick);

  input.focus();
};
// END